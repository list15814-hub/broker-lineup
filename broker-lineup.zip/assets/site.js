"use strict";

const brokerRows = [...document.querySelectorAll("[data-broker]")];
const searchForm = document.querySelector("#search-form");
const search = document.querySelector("#broker-search");
const filters = document.querySelector("#broker-filters");
const allFilter = filters.querySelector('input[value="all"]');
const headerSearch = document.querySelector(".header-search");
const noResults = document.querySelector("#empty");
const brokerTableScroll = document.querySelector("#broker-table-scroll");
const brokerTable = brokerTableScroll.querySelector("table");
const brokerTableBody = brokerTableScroll.querySelector("tbody");
const sortButtons = [...brokerTableScroll.querySelectorAll("[data-sort-key]")];
const resetCatalogSort = document.querySelector("#reset-catalog-sort");
const catalogSortStatus = document.querySelector("#catalog-sort-status");
const clearSearch = document.querySelector("#clear-search");
const brokerHeading = document.querySelector("#broker-heading");
const comparison = document.querySelector("#comparison");
const compareControls = document.querySelector("#compare-controls");
const compareButton = document.querySelector("#compare-button");
const count = document.querySelector("#compare-count");
const compareHint = document.querySelector("#compare-hint");
const compareAnnouncement = document.querySelector("#compare-announcement");
const clearSelection = document.querySelector("#clear-selection");
const labels = [...document.querySelector("#comparison-labels").children];
const comparisonTable = document.querySelector("#comparison-table");
const profileDialog = document.querySelector("#broker-profile");
const profileContent = document.querySelector("#profile-content");
const catalogText = [...brokerTable.querySelectorAll("[data-catalog-fit]")];
let fitFrame = 0;

function brokerValue(row, key) {
  return row.querySelector(`[data-value="${key}"]`).textContent.trim();
}

const brokers = brokerRows.map((row) => ({
  row,
  checkbox: row.querySelector('input[type="checkbox"]'),
  values: Object.fromEntries(labels.map(({ dataset: { field } }) => [field, brokerValue(row, field)])),
  categories: row.dataset.categories.split(" "),
  sortValues: Object.fromEntries([...row.querySelectorAll("[data-sort-value]")].map((cell) => [
    cell.dataset.value, { value: cell.dataset.sortValue, group: cell.dataset.sortGroup || "" },
  ])),
}));
let orderedBrokers = brokers;
let activeSort = null;
const catalogCollator = new Intl.Collator(document.documentElement.lang, { numeric: true, sensitivity: "base" });

function compareBrokers(first, second, key, numeric, direction) {
  const a = first.sortValues[key];
  const b = second.sortValues[key];
  if (!a || !b) return Number(!a) - Number(!b);
  if (!numeric) return catalogCollator.compare(a.value, b.value) * direction;
  const av = Number(a.value);
  const bv = Number(b.value);
  if ((av === 0) !== (bv === 0)) return (av - bv) * direction;
  const groupOrder = catalogCollator.compare(a.group, b.group);
  return groupOrder || (av - bv) * direction;
}

for (const button of sortButtons) {
  const header = button.closest("th");
  header.firstElementChild.hidden = true;
  button.hidden = false;
  button.addEventListener("click", () => {
    const ascending = header.getAttribute("aria-sort") !== "ascending";
    activeSort?.closest("th").removeAttribute("aria-sort");
    activeSort = button;
    const direction = ascending ? "ascending" : "descending";
    const { sortKey, sortKind } = button.dataset;
    header.setAttribute("aria-sort", direction);
    orderedBrokers = [...brokers].sort((a, b) => compareBrokers(a, b, sortKey, sortKind === "number", ascending ? 1 : -1));
    brokerTableBody.append(...orderedBrokers.map(({ row }) => row));
    resetCatalogSort.disabled = false;
    catalogSortStatus.textContent = catalogSortStatus.dataset[direction].replace("{field}", () => button.textContent.trim());
  });
}

resetCatalogSort.hidden = false;
resetCatalogSort.addEventListener("click", () => {
  activeSort.closest("th").removeAttribute("aria-sort");
  orderedBrokers = brokers;
  brokerTableBody.append(...brokers.map(({ row }) => row));
  catalogSortStatus.textContent = catalogSortStatus.dataset.reset;
  activeSort.focus({ preventScroll: true });
  activeSort = null;
  resetCatalogSort.disabled = true;
});

function fitCatalogText() {
  fitFrame = 0;
  if (brokerTableScroll.hidden) return;
  for (const label of catalogText) label.style.removeProperty("font-size");
  brokerTable.classList.add("is-measuring-text");

  const minimum = parseFloat(getComputedStyle(document.documentElement).fontSize) * 0.75;
  const range = document.createRange();
  const adjustments = [];
  for (const label of catalogText) {
    const available = label.getBoundingClientRect().width;
    if (available === 0) continue;
    range.selectNodeContents(label);
    const required = range.getBoundingClientRect().width;
    if (required <= available + 0.25) continue;
    const size = parseFloat(getComputedStyle(label).fontSize);
    const fitted = Math.max(minimum, Math.floor(size * available / required));
    if (fitted < size) adjustments.push([label, fitted]);
  }

  brokerTable.classList.remove("is-measuring-text");
  for (const [label, size] of adjustments) label.style.fontSize = `${size}px`;
}

function scheduleCatalogFit() {
  if (!fitFrame) fitFrame = requestAnimationFrame(fitCatalogText);
}

if (typeof ResizeObserver === "function") {
  let previousWidth;
  new ResizeObserver(([entry]) => {
    const width = entry.contentRect.width;
    if (width === previousWidth) return;
    previousWidth = width;
    scheduleCatalogFit();
  }).observe(brokerTableScroll);
} else {
  window.addEventListener("resize", scheduleCatalogFit);
}
document.fonts?.ready.then(scheduleCatalogFit);

function filterBrokers() {
  const query = search.value.toLowerCase().trim();
  const category = filters.querySelector("input:checked").value;
  for (const broker of brokers) {
    const { name, platform, detail } = broker.values;
    const categoryMatches = category === "all" || broker.categories.includes(category);
    const queryMatches = `${name} ${platform} ${detail}`.toLowerCase().includes(query);
    broker.row.hidden = !(categoryMatches && queryMatches);
  }
  noResults.hidden = brokers.some(({ row }) => !row.hidden);
  brokerTableScroll.hidden = !noResults.hidden;
  scheduleCatalogFit();
}

searchForm.hidden = false;
filters.hidden = false;
headerSearch.addEventListener("click", (event) => {
  if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
  event.preventDefault();
  search.focus();
});
if (location.hash === "#broker-search") search.focus();
search.addEventListener("input", filterBrokers);
filters.addEventListener("change", filterBrokers);
searchForm.addEventListener("submit", (event) => {
  event.preventDefault();
  filterBrokers();
  brokerHeading.focus();
});
clearSearch.addEventListener("click", () => {
  search.value = "";
  allFilter.checked = true;
  filterBrokers();
  allFilter.focus();
});
filterBrokers();

function revealRatingMethod() {
  if (location.hash === "#rating-method") document.querySelector("#rating-method").open = true;
}
window.addEventListener("hashchange", revealRatingMethod);
revealRatingMethod();

function selectedBrokers() {
  return orderedBrokers.filter(({ checkbox }) => checkbox.checked);
}

function updateSelection() {
  const size = selectedBrokers().length;
  const message = count.dataset.label.replace("{count}", String(size));
  compareControls.hidden = size === 0;
  compareButton.disabled = size < 2;
  count.textContent = message;
  compareHint.hidden = size !== 1;
  compareAnnouncement.textContent = size === 1 ? `${message}. ${compareHint.textContent}` : message;
}

function appendCell(row, tag, value, scope) {
  const cell = document.createElement(tag);
  if (scope) cell.scope = scope;
  const content = document.createElement("bdi");
  content.textContent = value;
  cell.append(content);
  row.append(cell);
}

if (typeof comparison.showModal === "function") {
  for (const { checkbox } of brokers) {
    checkbox.labels[0].hidden = false;
    checkbox.addEventListener("change", updateSelection);
  }
  if (selectedBrokers().length) updateSelection();

  clearSelection.addEventListener("click", () => {
    const selected = selectedBrokers();
    for (const { checkbox } of selected) checkbox.checked = false;
    updateSelection();
    const visible = selected.find(({ row }) => !row.hidden);
    (visible?.checkbox || brokerHeading).focus({ preventScroll: true });
  });

  compareButton.addEventListener("click", () => {
    const selected = selectedBrokers();
    if (selected.length < 2) return;

    comparisonTable.replaceChildren();
    const header = comparisonTable.createTHead().insertRow();
    appendCell(header, "th", labels[0].textContent, "col");
    for (const { values } of selected) appendCell(header, "th", values.name, "col");

    const body = comparisonTable.createTBody();
    for (const label of labels.slice(1)) {
      const row = body.insertRow();
      appendCell(row, "th", label.textContent, "row");
      for (const { values } of selected) appendCell(row, "td", values[label.dataset.field]);
    }
    comparison.showModal();
  });
}

if (typeof profileDialog.showModal === "function") {
  const reviewLinks = [...document.querySelectorAll("a[data-review]")];
  const reviewsByHash = new Map(reviewLinks.map((link) => [`#${link.dataset.review}`, link]));
  const reviewActions = document.querySelector("#review-dialog-actions");
  let profileOpener;
  let reviewRequest;

  async function openReview(link, opener) {
    reviewRequest?.abort();
    const request = new AbortController();
    reviewRequest = request;
    opener?.setAttribute("aria-busy", "true");

    try {
      const response = await fetch(link.href, { signal: request.signal, mode: "same-origin" });
      if (!response.ok) throw new Error("Review request failed");

      const page = document.createElement("template");
      page.innerHTML = await response.text();
      if (request.signal.aborted) return;
      const header = page.content.querySelector(".review-page-report > .profile-header");
      const body = page.content.querySelector(".review-page-report > .profile-body");
      if (!header || !body) throw new Error("Review content missing");

      for (const container of [header, body]) {
        for (const node of container.querySelectorAll("a[href], img[src]")) {
          const attribute = node.matches("a") ? "href" : "src";
          const value = node.getAttribute(attribute);
          if (!value.startsWith("#")) node.setAttribute(attribute, new URL(value, response.url).href);
        }
        for (const heading of container.querySelectorAll("h1, h2, h3, h4")) {
          const replacement = document.createElement(`h${Number(heading.tagName[1]) + 1}`);
          for (const { name, value } of heading.attributes) replacement.setAttribute(name, value);
          replacement.append(...heading.childNodes);
          heading.replaceWith(replacement);
        }
      }

      const identity = header.querySelector(".profile-identity");
      const title = identity.querySelector(".profile-title");
      const actions = reviewActions.content.firstElementChild.cloneNode(true);
      actions.querySelector("a").href = link.href;
      const heading = document.createElement("div");
      heading.className = "dialog-heading";
      identity.replaceWith(heading);
      heading.append(identity, actions);

      profileContent.replaceChildren(header, body);
      profileDialog.setAttribute("aria-labelledby", title.id);
      if (!profileDialog.open) {
        profileOpener = opener;
        profileDialog.showModal();
      }
      profileContent.scrollTop = 0;
      actions.querySelector(".close-button").focus();
    } catch {
      if (!request.signal.aborted) location.assign(link.href);
    } finally {
      if (reviewRequest === request) reviewRequest = undefined;
      opener?.removeAttribute("aria-busy");
    }
  }

  for (const link of reviewLinks) {
    link.addEventListener("click", (event) => {
      if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      event.preventDefault();
      openReview(link, link);
    });
  }
  profileContent.addEventListener("click", (event) => {
    const link = event.target.closest(".profile-nav a");
    if (!link || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const heading = document.getElementById(`${link.hash.slice(1)}-title`);
    if (!heading) return;
    event.preventDefault();
    const panel = heading.parentElement;
    const header = profileContent.querySelector(".profile-header");
    const offset = panel.getBoundingClientRect().top - header.getBoundingClientRect().bottom;
    profileContent.scrollTop += offset - 8;
    heading.focus({ preventScroll: true });
  });
  profileDialog.addEventListener("click", (event) => {
    if (event.target === profileDialog) profileDialog.close();
  });
  profileDialog.addEventListener("close", () => {
    if (profileDialog.open) return;
    if (profileOpener?.isConnected) profileOpener.focus();
    profileOpener = undefined;
    profileContent.replaceChildren();
    profileDialog.removeAttribute("aria-labelledby");
  });
  function openReviewFromHash() {
    const link = reviewsByHash.get(location.hash);
    if (link) openReview(link);
  }

  window.addEventListener("hashchange", openReviewFromHash);
  openReviewFromHash();
}
